document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('playerName');
    const debug = document.getElementById('playerDebug');
    const list = document.getElementById('autocompleteList');

    let suggestions = [];

    input.addEventListener('input', () => {
        const term = input.value.trim();
        list.innerHTML = '';
        if (term.length >= 1) {
            fetch(`players.php?action=autocomplete&name=${encodeURIComponent(term)}`)
                .then(res => res.json())
                .then(data => {
                    console.log('Resposta do servidor:', data); // Depuração
                    suggestions = data.players || [];
                    console.log('Sugestões antes de renderizar:', suggestions); // Depuração
                    debug.innerHTML = `Registros encontrados: ${data.count}`;
                    if (suggestions.length > 0) {
                        list.innerHTML = ''; // Limpa a lista antes de renderizar
                        suggestions.forEach(name => {
                            const li = document.createElement('li');
                            li.textContent = name;
                            li.onclick = () => {
                                input.value = '';
                                suggestions = [];
                                list.innerHTML = '';
                                if (!players.includes(name)) {
                                    players.push(name);
                                    updatePlayerList();
                                }
                            };
                            list.appendChild(li);
                        });
                    } else {
                        debug.innerHTML = 'Nenhum jogador encontrado';
                    }
                })
                .catch(error => {
                    console.error('Erro ao buscar jogadores:', error);
                    debug.innerHTML = 'Erro ao buscar jogadores';
                });
        } else {
            debug.innerHTML = '';
        }
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('#autocompleteList') && e.target !== input) {
            list.innerHTML = '';
        }
    });

    window.addPlayer = function () {
        const name = input.value.trim();
        if (name === '') return;

        if (!players.includes(name)) {
            players.push(name);
            updatePlayerList();
        }

        if (!suggestions.includes(name)) {
            fetch(`players.php?action=add&name=${encodeURIComponent(name)}`)
                .then(res => res.json())
                .then(data => {
                    if (!data.success) {
                        console.error('Erro ao adicionar jogador:', data.error);
                    }
                });
        }

        input.value = '';
        list.innerHTML = '';
        debug.innerHTML = '';
    };
});